PLDS Enhanced Interactive Demo
==============================

Files
- app.py       Local Python web server (no third-party packages required)
- index.html   Login page and colourful PLDS dashboard
- style.css    Responsive colourful UI and feature cards
- script.js    Feature interactions and demo calculations

How to run on Windows
1. Extract this ZIP file.
2. Open the extracted PLDS_Enhanced_Interactive folder.
3. Click the folder address bar, type cmd, and press Enter.
4. Run: python app.py
5. Open Chrome at: http://127.0.0.1:8000
6. The Home page opens first. Use the colourful menu across the top to open one feature at a time. Use Login in the top-right when needed. Keep the CMD window open while using the website.

Demo login
Enter any valid-looking email address and a password of at least 4 characters.
This is a front-end demo login, NOT secure production authentication. Do not use a real password.

Features included
- Login/logout and show/hide password
- Product Health Card with illustrative score
- Repair vs Replace cost comparison
- Eco Impact Score (illustrative, not a carbon audit)
- Failure Risk Analysis (rule-based demo estimate)
- Product Lifecycle Chatbot (prewritten local responses; no live AI service)
- Language Selection (basic navigation labels)
- Reports & History with CSV export
- QR Product Passport (decorative QR-style code; not a real scannable QR)
- Product Image Upload and local preview
- Clickable colourful cards and responsive dashboard layout
- Horizontal top navigation for one-feature-at-a-time views
- Login page opens first; successful demo sign-in opens the colourful Home dashboard
- About page is the final item in the top navigation

Notes
- Assessment history and preferences are stored in your browser localStorage.
- Demo calculations are educational estimates, not professional diagnostics.
- This package is a standalone replacement/demo based on the project structure discussed in chat; it does not merge unknown changes from your original project because the original ZIP was not attached.
